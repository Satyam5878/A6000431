exec "hadoop fs"
