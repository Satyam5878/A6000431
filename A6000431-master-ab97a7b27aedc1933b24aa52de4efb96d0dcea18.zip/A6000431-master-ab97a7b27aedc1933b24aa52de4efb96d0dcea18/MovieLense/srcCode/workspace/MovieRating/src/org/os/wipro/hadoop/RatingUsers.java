package org.os.wipro.hadoop;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class RatingUsers implements WritableComparable{
	private float rating;
	private float ratingSquare;
	private int noOfUsers;
	
	public RatingUsers(float rating,float ratingSquare,int noOfUsers){
		this.rating = rating;
		this.ratingSquare = ratingSquare;
		this.noOfUsers = noOfUsers;
		
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		// TODO Auto-generated method stub
		rating = in.readFloat();
		ratingSquare = in.readFloat();
		noOfUsers = in.readInt();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		// TODO Auto-generated method stub
		out.writeFloat(rating);
		out.writeFloat(ratingSquare);
		out.writeInt(noOfUsers);
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
//Getters and Setters
	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public float getRatingSquare() {
		return ratingSquare;
	}

	public void setRatingSquare(float ratingSquare) {
		this.ratingSquare = ratingSquare;
	}

	public int getNoOfUsers() {
		return noOfUsers;
	}

	public void setNoOfUsers(int noOfUsers) {
		this.noOfUsers = noOfUsers;
	}
	

}
