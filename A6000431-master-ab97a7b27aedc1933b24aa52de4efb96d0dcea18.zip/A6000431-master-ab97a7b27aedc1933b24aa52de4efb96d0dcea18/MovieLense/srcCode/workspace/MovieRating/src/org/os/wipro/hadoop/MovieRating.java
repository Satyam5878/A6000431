package org.os.wipro.hadoop;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class MovieRating {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
		
		Configuration conf = new Configuration();
		
		String[] otherArgs = new GenericOptionsParser(conf,args).getRemainingArgs();
		if(otherArgs.length < 2){
			System.out.println("Provide <inputlocation> <outputlocation>?");
			System.exit(1);
		}
		
		Job job = Job.getInstance(conf,"MovieRating");
		job.setJarByClass(MovieRating.class);
		job.setMapperClass(MovieRatingMapper.class);
		job.setReducerClass(MovieRatingReducer.class);
		
		job.setMapOutputKeyClass(IntWritable.class);
		job.setMapOutputValueClass(FloatWritable.class);
		
		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(RatingUsers.class);
		
		FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
		FileOutputFormat.setOutputPath(job, new Path(otherArgs[0]));
		
		boolean success = job.waitForCompletion(true);
		if(success){
			System.out.print("Code to second map-reduce program");
		}
	}
	public static class MovieRatingMapper extends Mapper<LongWritable,Text,IntWritable,FloatWritable>{
		
		public void map(LongWritable key,Text value,Context context) throws IOException, InterruptedException{
			String line = value.toString();
			String[] line_split = line.split(",");
			if(line_split.length == 4){
				context.write(new IntWritable(Integer.parseInt(line_split[1])), new FloatWritable(Float.parseFloat(line_split[2])));
			}
		}
		
	}
	
	public static class MovieRatingReducer extends Reducer<IntWritable,FloatWritable,IntWritable,RatingUsers>{
		public void reduce(IntWritable key,Iterable<FloatWritable> values,Context context) throws IOException, InterruptedException{
			int count = 0;
			float ratingSum = 0;
			float ratingSquareSum = 0;
			for(FloatWritable tmpRatingWritable : values){
				float tmpRating = tmpRatingWritable.get();
				ratingSum += tmpRating;
				ratingSquareSum += tmpRating*tmpRating;
				count++;
			}
			context.write(key, new RatingUsers(ratingSum,ratingSquareSum,count));
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
